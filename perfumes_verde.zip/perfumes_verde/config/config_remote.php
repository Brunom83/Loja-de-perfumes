<?php
// Configuração para ambiente remoto (AeonFree)

define('DB_HOST', 'sql202.iceiy.com');
define('DB_NAME', 'icei_39079010_perfumesverde');
define('DB_USER', 'icei_39079010');
define('DB_PASS', 'WsoTIe3jS7X9');
define('BASE_URL', 'https://perfumesverdes.iceiy.com');

date_default_timezone_set('Europe/Lisbon');
?>

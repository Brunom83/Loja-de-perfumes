<?php require_once __DIR__ . '/../includes/header.php'; ?>

<h2 style="color:Black;">Contacta-nos</h2>
<p style="color: black;">Email: apoio@perfumesverdes.com</p>
<p style="color: black;">Telefone: +351 912 345 678</p>
<p style="color: black;">Morada: Aveiro, Portugal</p>
